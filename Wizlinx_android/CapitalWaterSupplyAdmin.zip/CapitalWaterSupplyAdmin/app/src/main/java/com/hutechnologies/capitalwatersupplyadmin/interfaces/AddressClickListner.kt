package com.hutechnologies.capitalwatersupplyadmin.interfaces

import android.view.View
import com.hutechnologies.capitalwatersupplyadmin.models.Addresses
import com.hutechnologies.capitalwatersupplyadmin.models.Tanker

interface AddressClickListner {

    fun onAddressItemClickListner(view: View, address: Addresses)

}