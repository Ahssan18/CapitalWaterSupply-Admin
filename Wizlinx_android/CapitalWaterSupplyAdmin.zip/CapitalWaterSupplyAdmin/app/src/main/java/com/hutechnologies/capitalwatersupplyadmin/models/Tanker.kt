package com.hutechnologies.capitalwatersupplyadmin.models

data class Tanker(
    var id:String? = null,
    val tankerName: String? = null,
    val tankerType : String? = null,
//    val tankerPrice: String? = null,
//    val address:String? = null
)