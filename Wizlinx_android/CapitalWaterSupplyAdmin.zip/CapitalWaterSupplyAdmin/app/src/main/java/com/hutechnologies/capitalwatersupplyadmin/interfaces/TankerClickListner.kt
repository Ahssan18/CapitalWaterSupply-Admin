package com.hutechnologies.capitalwatersupplyadmin.interfaces

import android.view.View
import com.hutechnologies.capitalwatersupplyadmin.models.Tanker

interface TankerClickListner {

    fun onAddressItemClickListner(view: View, tanker: Tanker)

}