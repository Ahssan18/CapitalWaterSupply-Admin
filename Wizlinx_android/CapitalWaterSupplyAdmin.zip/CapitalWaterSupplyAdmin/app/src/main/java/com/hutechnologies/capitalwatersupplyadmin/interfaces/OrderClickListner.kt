package com.hutechnologies.capitalwatersupplyadmin.interfaces

import android.view.View
import com.hutechnologies.capitalwatersupplyadmin.models.Addresses
import com.hutechnologies.capitalwatersupplyadmin.models.Order
import com.hutechnologies.capitalwatersupplyadmin.models.Tanker

interface OrderClickListner {

    fun onOrderItemClickListner(view: View, order:Order)

}