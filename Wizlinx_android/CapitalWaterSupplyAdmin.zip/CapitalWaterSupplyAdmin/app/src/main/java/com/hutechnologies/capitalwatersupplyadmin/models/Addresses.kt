package com.hutechnologies.capitalwatersupplyadmin.models

data class Addresses(
    var id:String? = null,
    val address:String? = null,
    val price : String? = null
)