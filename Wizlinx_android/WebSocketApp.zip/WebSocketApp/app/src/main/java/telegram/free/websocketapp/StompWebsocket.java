package telegram.free.websocketapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import io.reactivex.disposables.CompositeDisposable;
import rx.Producer;
import rx.Subscriber;
import rx.functions.Action1;
import ua.naiksoftware.stomp.Stomp;
import ua.naiksoftware.stomp.client.StompClient;
import ua.naiksoftware.stomp.client.StompMessage;


public class StompWebsocket extends AppCompatActivity {
    private static final String TAG = "StompWebsocket";
    private StompClient mStompClient;
    private ImageView ivSend;
    private EditText editTextMessage;
    private TextView textView;
    private CompositeDisposable compositeDisposable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stomp_websocket);
        init();
        clickListener();
//        resetSubscriptions();
        //        mStompClient.disconnect();
        mStompClient.lifecycle().subscribe(lifecycleEvent -> {
            switch (lifecycleEvent.getType()) {

                case OPENED:

                    Log.d(TAG, "Stomp connection opened successfully");
                    break;

                case ERROR:
                    Log.e(TAG, "Error", lifecycleEvent.getException());
                    break;

                case CLOSED:
                    Log.d(TAG, "Stomp connection closed");
                    break;
            }
        });
    }

    private void clickListener() {
        ivSend.setOnClickListener(v -> {
            String msg = editTextMessage.getText().toString();
            if (!msg.isEmpty()) {
                if (mStompClient != null) {
                    mStompClient.topic("/topic/chat").subscribe(new Action1<StompMessage>() {
                        @Override
                        public void call(StompMessage topicMessage) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(StompWebsocket.this, "___"+ topicMessage.getPayload(), Toast.LENGTH_SHORT).show();
                                }
                            });
                            Log.d(TAG, topicMessage.getPayload());
                        }


                    });
                    mStompClient.send("/app/chat", msg).subscribe(new Subscriber<Object>() {


                        @Override
                        public void onCompleted() {
                            editTextMessage.setText("");

                        }

                        @Override
                        public void onError(Throwable e) {
                          e.printStackTrace();
                        }

                        @Override
                        public void onNext(Object o) {

                        }
                    });
                    mStompClient.send("/app/chat", msg).subscribe(new Subscriber<Object>() {
                        @Override
                        public void onCompleted() {
                            editTextMessage.setText("");
                            Log.d(TAG, "Sent data!");
                        }

                        @Override
                        public void onError(Throwable error) {
                            editTextMessage.setText("");
                            Log.e(TAG, "Encountered error while sending data!", error);
                        }

                        @Override
                        public void onNext(Object o) {

                        } // useless
                    });
                } else {
                    Toast.makeText(StompWebsocket.this, "web client null", Toast.LENGTH_SHORT).show();
                }
//                    Toast.makeText(StompWebsocket.this, "web client null", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
//        mStompClient.disconnect();
//        if (compositeDisposable != null) compositeDisposable.dispose();
        super.onDestroy();
    }


    private void init() {
        ivSend = findViewById(R.id.iv_send);
        editTextMessage = findViewById(R.id.et_message);
        textView = findViewById(R.id.recycle_view);
//        mStompClient = Stomp.over(Stomp.ConnectionProvider.OKHTTP, "ws://c23663fe735a.ngrok.io/websocket");
        mStompClient = Stomp.over(Stomp.ConnectionProvider.OKHTTP, "ws://8d9c6fc11688.ngrok.io/websocket",null,null);
        mStompClient.setHeartbeat(10000);
        mStompClient.connect();
        mStompClient.topic("/topic/chat").subscribe(new Subscriber<StompMessage>() {
            @Override
            public void onCompleted() {
                Toast.makeText(StompWebsocket.this, "Subscribe Succesfully", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(Throwable e) {
                e.printStackTrace();
            }

            @Override
            public void onNext(StompMessage stompMessage) {

            }
        });

    }

    private void resetSubscriptions() {
        if (compositeDisposable != null) {
            compositeDisposable.dispose();
        }
        compositeDisposable = new CompositeDisposable();
    }
}