package telegram.free.websocketapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    private ImageView ivSend;
    private EditText editTextMessage;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        init();
        clickListener();
    }

    private void clickListener() {
    }

    private void init() {
        ivSend = findViewById(R.id.iv_send);
        editTextMessage = findViewById(R.id.et_message);
        textView = findViewById(R.id.recycle_view);
    }
}