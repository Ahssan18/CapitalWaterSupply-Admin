package com.hutechnologies.capitalwatersupplycustomer.models

data class Addresses(
    var id:String? = null,
    val address:String? = null,
    val price : String? = null
)