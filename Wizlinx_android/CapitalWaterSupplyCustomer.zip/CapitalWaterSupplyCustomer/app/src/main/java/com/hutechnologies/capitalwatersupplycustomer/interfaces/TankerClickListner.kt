package com.hutechnologies.capitalwatersupplycustomer.interfaces

import android.view.View
import com.hutechnologies.capitalwatersupplycustomer.models.Tanker

interface TankerClickListner {

    fun onTankerItemClickListner(view: View, tanker: Tanker)

}